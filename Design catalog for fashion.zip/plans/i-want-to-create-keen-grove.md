# Plan: Fashion Design Catalog — Keen Grove

## Context
Build a fashion design catalog called "Keen Grove" from a blank-slate app (App.tsx renders an empty div). The catalog showcases shoes, outfits, dresses, and bags with an editorial luxury aesthetic: high-contrast true-white ground, old-style serif display type (Playfair Display), clean sans body (Outfit), generous whitespace, asymmetric grid layout, and Unsplash photography.

## Aesthetic Stance
- **Direction:** Editorial (Monocle / The Gentlewoman)
- **Ground:** True white (`#ffffff`) with black (`#0a0a0a`) type
- **Accent:** Warm terracotta `#c8613a` used sparingly on tags and CTAs
- **Display font:** Playfair Display (Google Fonts) — headings + brand name
- **Body font:** Outfit (Google Fonts) — labels, filters, prices
- **Card radius:** 2px (barely-there — keeps the editorial feel)

## Files to Create / Modify

### `src/index.css`
- Add Google Fonts `@import` for Playfair Display and Outfit at the top (before `@import 'tailwindcss'`)
- Add Tailwind v4 `@theme` block with design tokens: `--background`, `--foreground`, `--card`, `--primary` (terracotta), `--muted`, `--border`, `--radius`, `--font-display`, `--font-body`

### `src/App.tsx`
Complete implementation with all UI in one file (appropriate for this catalog scope):

1. **Header** — "KEEN GROVE" wordmark in Playfair Display, nav links (New Arrivals, Collections, About), minimal hairline border-bottom

2. **Hero Strip** — Full-width editorial headline "The New Season Edit" over a large Unsplash fashion image with dark overlay, sub-headline copy

3. **Filter Bar** — Category tabs: All | Shoes | Outfits | Dresses | Bags — React `useState` drives active category, filters the product grid

4. **Product Grid** — CSS Grid, 4 cols desktop / 2 cols tablet / 1 col mobile. 12 product cards covering all 4 categories:
   - Card: Unsplash image (aspect-ratio 3/4, `object-fit: cover`), brand tag (terracotta pill), product name in Playfair Display, brief descriptor in Outfit, price

5. **Quick-view hover** — On card hover: image scales subtly (transform scale-105), overlay button "View Details" fades in

6. **Footer** — simple centered wordmark + copyright

## Unsplash Image Strategy
Use specific Unsplash photo IDs for fashion context:
- Shoes: `photo-1542291026-7eec264c27ff`, `photo-1543163521-1bf539c55dd2`
- Outfits: `photo-1515886657613-9f3515b0c78f`, `photo-1469334031218-e382a71b716b`
- Dresses: `photo-1496747611176-843222e1e57c`, `photo-1539109136881-3be0616acf4b`
- Bags: `photo-1548036328-c9fa89d128fa`, `photo-1584917865442-de89df76afd3`
- Additional: `photo-1490481651871-ab68de25d43d`, `photo-1529139574466-a303027c1d8b`, `photo-1434389677669-e08b4cac3105`, `photo-1445205170230-053b83016050`

## Product Data (inline constant in App.tsx)
12 items with: id, name, category, brand, price, unsplashId, description

## Verification
- Filter buttons switch category, grid re-renders with filtered items
- All 4 categories contain items
- Fonts load (Playfair Display visible on headings)
- Images render from Unsplash
- Responsive: 4→2→1 col grid
